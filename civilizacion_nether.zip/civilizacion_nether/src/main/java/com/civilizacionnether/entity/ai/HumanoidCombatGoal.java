package com.civilizacionnether.entity.ai;

import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherHumanoidEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/**
 * Combate de los humanos del Nether. Según el tipo: cuerpo a cuerpo, arco de rubí, hechizo o ambos.
 * Si el humano va montado (Caballero del Rubí) mueve a su montura.
 */
public class HumanoidCombatGoal extends Goal {
    private final NetherHumanoidEntity mob;
    private int cooldown;
    private int windup;
    private int repath;
    private boolean windupRanged;

    public HumanoidCombatGoal(NetherHumanoidEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = mob.getTarget();
        return target != null && target.isAlive() && !mob.isOrderedToSit();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse() && mob.canAttack(mob.getTarget());
    }

    @Override
    public void start() {
        mob.setAggressive(true);
        windup = 0;
        repath = 0;
    }

    @Override
    public void stop() {
        mob.setAggressive(false);
        mover().getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    private Mob mover() {
        return mob.getVehicle() instanceof Mob vehicle ? vehicle : mob;
    }

    @Override
    public void tick() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            return;
        }
        HumanoidType type = mob.getHumanoidType();
        mob.getLookControl().setLookAt(target, 30.0f, 30.0f);
        double distSq = mob.distanceToSqr(target);
        boolean sees = mob.getSensing().hasLineOfSight(target);
        if (cooldown > 0) {
            cooldown--;
        }

        // carga de ataques a distancia (sincronizada con la animación)
        if (windup > 0) {
            if (--windup == 0 && target.isAlive() && sees) {
                if (windupRanged && type.combat == HumanoidType.Combat.BOW) {
                    mob.shootArrow(target);
                } else {
                    mob.castBolt(target);
                }
            }
            return;
        }

        boolean melee = type.combat == HumanoidType.Combat.MELEE
                || (type.combat == HumanoidType.Combat.SPELL_MELEE && distSq < 16.0);
        double speed = mob.isPassenger() ? 1.6 : 1.2;

        if (melee) {
            double reach = mob.isPassenger() ? 3.4 : mob.getBbWidth() * 2.0 + target.getBbWidth();
            if (--repath <= 0) {
                repath = 6 + mob.getRandom().nextInt(4);
                mover().getNavigation().moveTo(target, speed);
            }
            if (distSq <= reach * reach && cooldown <= 0) {
                cooldown = type.attackCooldown;
                mob.performMelee(target);
            }
            return;
        }

        // A distancia: acercarse hasta tener línea de visión a ~14 bloques; retroceder si está muy cerca
        double ideal = 14.0;
        if (!sees || distSq > ideal * ideal) {
            if (--repath <= 0) {
                repath = 8;
                mover().getNavigation().moveTo(target, speed);
            }
        } else if (distSq < 25.0 && type.combat != HumanoidType.Combat.SPELL_MELEE) {
            if (--repath <= 0) {
                repath = 10;
                double dx = mob.getX() - target.getX();
                double dz = mob.getZ() - target.getZ();
                mover().getNavigation().moveTo(mob.getX() + dx, mob.getY(), mob.getZ() + dz, 1.15);
            }
        } else {
            mover().getNavigation().stop();
        }

        if (sees && distSq < 20.0 * 20.0 && cooldown <= 0) {
            cooldown = type.attackCooldown;
            windupRanged = true;
            if (type.combat == HumanoidType.Combat.BOW) {
                mob.playAction("attack_bow");
                windup = 14;
            } else {
                mob.playAction("attack_spell");
                windup = 8;
            }
        }
    }
}
