package com.civilizacionnether.entity;

import com.civilizacionnether.entity.ai.DragonCombatGoal;
import com.civilizacionnether.entity.ai.FollowOwnerSimpleGoal;
import com.civilizacionnether.registry.ModEntities;
import com.civilizacionnether.registry.ModItems;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Dragón del Nether domesticable y montable.
 * <ul>
 *   <li>Domesticar: rubí (el de rubí es el más dócil).</li>
 *   <li>Silla: clic derecho con una silla de montar. Montar: clic derecho con la mano vacía.</li>
 *   <li>Vuelo: mira hacia arriba y avanza para despegar; vuela hacia donde miras. Tecla R: aliento.</li>
 *   <li>Vínculo (0-100): sube al alimentarlo con rubí, al volar juntos y al vencer enemigos. Mejora vuelo y aliento.</li>
 *   <li>Reproducción: chuleta de cerdo asada (igual que la civilización).</li>
 * </ul>
 */
public class NetherDragonEntity extends TamableAnimal implements GeoEntity {
    private static final EntityDataAccessor<Boolean> SADDLED = SynchedEntityData.defineId(NetherDragonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> ARMORED = SynchedEntityData.defineId(NetherDragonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> BOND = SynchedEntityData.defineId(NetherDragonEntity.class, EntityDataSerializers.INT);

    private static final String P = "animation.nether_dragon.";
    private static final RawAnimation IDLE = RawAnimation.begin().thenLoop(P + "idle");
    private static final RawAnimation WALK = RawAnimation.begin().thenLoop(P + "walk");
    private static final RawAnimation FLY = RawAnimation.begin().thenLoop(P + "fly");
    private static final RawAnimation GLIDE = RawAnimation.begin().thenLoop(P + "glide");
    private static final RawAnimation SIT = RawAnimation.begin().thenLoop(P + "sit");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final DragonType dragonType;
    private int breathTicks;
    private int breathCooldown;
    private int rideBondTimer;

    public NetherDragonEntity(EntityType<? extends TamableAnimal> entityType, Level level, DragonType type) {
        super(entityType, level);
        this.dragonType = type;
        this.xpReward = 40;
    }

    public DragonType getDragonType() {
        return dragonType;
    }

    public static AttributeSupplier.Builder createAttributes(DragonType type) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, type.health)
                .add(Attributes.ATTACK_DAMAGE, type.biteDamage)
                .add(Attributes.ARMOR, type.armor)
                .add(Attributes.MOVEMENT_SPEED, type.speed)
                .add(Attributes.FLYING_SPEED, type.flyingSpeed)
                .add(Attributes.FOLLOW_RANGE, 48.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.9)
                .add(Attributes.STEP_HEIGHT, 1.5);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(SADDLED, false);
        builder.define(ARMORED, false);
        builder.define(BOND, 0);
    }

    public boolean isSaddled() {
        return entityData.get(SADDLED);
    }

    public boolean isArmored() {
        return entityData.get(ARMORED);
    }

    public int getBond() {
        return entityData.get(BOND);
    }

    public void addBond(int amount) {
        entityData.set(BOND, Mth.clamp(getBond() + amount, 0, 100));
    }

    // ------------------------------------------------------------------ IA
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new DragonCombatGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerSimpleGoal(this, 1.1, 14.0, 6.0));
        this.goalSelector.addGoal(5, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.6));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 12.0f));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this, NetherHumanoidEntity.class, NetherDragonEntity.class,
                AbstractGolem.class, AbstractVillager.class));
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false,
                e -> isTame() && NetherHumanoidEntity.isHostileTarget(e)));
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (target instanceof NetherHumanoidEntity || target instanceof NetherDragonEntity
                || target instanceof AbstractVillager || target instanceof AbstractGolem) {
            return false;
        }
        if (isTame() && target instanceof Player) {
            return false; // un dragón domesticado nunca ataca jugadores
        }
        return super.canAttack(target);
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        return !NetherHumanoidEntity.isAlly(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        Entity attacker = source.getEntity();
        if (attacker instanceof NetherHumanoidEntity || attacker instanceof NetherDragonEntity) {
            return false;
        }
        if (attacker != null && hasPassenger(attacker)) {
            return false;
        }
        if (isOrderedToSit() && attacker != null && !(attacker instanceof Player)) {
            setOrderedToSit(false);
        }
        return super.hurt(source, amount);
    }

    @Override
    public int getArmorValue() {
        return super.getArmorValue() + (isArmored() ? 12 : 0);
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, DamageSource source) {
        return false;
    }

    /** Permite aparecer y moverse en la oscuridad del Nether (los animales normales necesitan luz o pasto). */
    @Override
    public float getWalkTargetValue(net.minecraft.core.BlockPos pos, net.minecraft.world.level.LevelReader level) {
        return 0.0f;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void awardKillScore(Entity killed, int score, DamageSource source) {
        super.awardKillScore(killed, score, source);
        if (isTame()) {
            addBond(2);
        }
    }

    // ------------------------------------------------------------------ aliento
    public boolean canBreathe() {
        return breathCooldown <= 0 && breathTicks <= 0 && !isBaby();
    }

    public void startBreath() {
        if (!canBreathe() || level().isClientSide) {
            return;
        }
        breathTicks = 30;
        breathCooldown = 90 - getBond() / 3;
        triggerAnim("action", "breath");
        playSound(SoundEvents.ENDER_DRAGON_SHOOT, 2.0f, 0.8f + getRandom().nextFloat() * 0.2f);
    }

    public void bite(LivingEntity target) {
        triggerAnim("action", "bite");
        doHurtTarget(target);
        playSound(SoundEvents.RAVAGER_ATTACK, 1.5f, 0.7f);
    }

    private Vec3 aimDirection() {
        if (getControllingPassenger() instanceof Player rider) {
            return rider.getLookAngle();
        }
        LivingEntity target = getTarget();
        if (target != null) {
            return target.getBoundingBox().getCenter().subtract(mouthPosition()).normalize();
        }
        return Vec3.directionFromRotation(getXRot(), getYRot());
    }

    private Vec3 mouthPosition() {
        Vec3 forward = Vec3.directionFromRotation(0, yBodyRot);
        return position().add(forward.scale(5.5)).add(0, 3.2, 0);
    }

    private void tickBreath(ServerLevel server) {
        Vec3 mouth = mouthPosition();
        Vec3 dir = aimDirection();
        ParticleOptions main = switch (dragonType) {
            case RUBI -> ParticleTypes.FLAME;
            case OBSIDIANA -> ParticleTypes.REVERSE_PORTAL;
            case FUEGO -> ParticleTypes.LAVA;
            case HUESO -> ParticleTypes.SOUL_FIRE_FLAME;
        };
        ParticleOptions second = switch (dragonType) {
            case RUBI -> ParticleTypes.CRIMSON_SPORE;
            case OBSIDIANA -> ParticleTypes.LARGE_SMOKE;
            case FUEGO -> ParticleTypes.FLAME;
            case HUESO -> ParticleTypes.SOUL;
        };
        for (int i = 1; i <= 12; i++) {
            Vec3 p = mouth.add(dir.scale(i * 1.1));
            double spread = 0.08 * i;
            server.sendParticles(main, p.x, p.y, p.z, 3, spread, spread, spread, 0.02);
            if (i % 2 == 0) {
                server.sendParticles(second, p.x, p.y, p.z, 2, spread, spread, spread, 0.01);
            }
        }
        if (breathTicks % 5 != 0) {
            return;
        }
        float damage = dragonType.breathDamage * (1.0f + getBond() / 200.0f);
        Vec3 end = mouth.add(dir.scale(13));
        AABB area = new AABB(mouth, end).inflate(2.5);
        for (LivingEntity e : server.getEntitiesOfClass(LivingEntity.class, area, e -> e != this && e.isAlive() && !hasPassenger(e))) {
            if (NetherHumanoidEntity.isAlly(e) && (isTame() || !(e instanceof Player))) {
                continue;
            }
            Vec3 to = e.getBoundingBox().getCenter().subtract(mouth);
            double along = to.dot(dir);
            if (along < 0 || along > 13) {
                continue;
            }
            double off = to.subtract(dir.scale(along)).length();
            if (off > 1.2 + along * 0.18) {
                continue;
            }
            e.hurt(damageSources().mobAttack(this), damage);
            switch (dragonType) {
                case RUBI -> e.setRemainingFireTicks(100);
                case OBSIDIANA -> {
                    e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 1));
                    e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
                }
                case FUEGO -> e.setRemainingFireTicks(160);
                case HUESO -> {
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 60, 0));
                    e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                }
            }
        }
    }

    // ------------------------------------------------------------------ tick
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            return;
        }
        if (breathCooldown > 0) {
            breathCooldown--;
        }
        if (breathTicks > 0) {
            breathTicks--;
            if (level() instanceof ServerLevel server) {
                tickBreath(server);
            }
        }
        if (isVehicle() && getControllingPassenger() instanceof Player && ++rideBondTimer >= 400) {
            rideBondTimer = 0;
            addBond(1);
        }
        if (tickCount % 200 == 0 && getHealth() < getMaxHealth()) {
            heal(1.0f);
        }
    }

    // ------------------------------------------------------------------ montar y volar
    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        if (isSaddled() && getFirstPassenger() instanceof Player player && isOwnedBy(player)) {
            return player;
        }
        return super.getControllingPassenger();
    }

    @Override
    protected void tickRidden(Player player, Vec3 input) {
        super.tickRidden(player, input);
        setYRot(player.getYRot());
        yRotO = getYRot();
        setXRot(player.getXRot() * 0.5f);
        setRot(getYRot(), getXRot());
        yBodyRot = getYRot();
        yHeadRot = getYRot();
    }

    @Override
    protected Vec3 getRiddenInput(Player player, Vec3 input) {
        float strafe = player.xxa * 0.5f;
        float forward = player.zza;
        if (forward <= 0.0f) {
            forward *= 0.3f;
        }
        return new Vec3(strafe, 0.0, forward);
    }

    @Override
    protected float getRiddenSpeed(Player player) {
        return (float) getAttributeValue(Attributes.MOVEMENT_SPEED) * 1.1f;
    }

    @Override
    public void travel(Vec3 input) {
        if (isAlive() && isVehicle() && getControllingPassenger() instanceof Player rider) {
            boolean airborne = !onGround() && !isInLava() && !isInWater();
            // Despegue: avanzar mirando hacia arriba
            if (!airborne && input.z > 0 && rider.getXRot() < -20.0f) {
                setDeltaMovement(getDeltaMovement().add(0.0, 0.7, 0.0));
                move(MoverType.SELF, getDeltaMovement());
                return;
            }
            if (airborne) {
                double speed = getAttributeValue(Attributes.FLYING_SPEED) * (1.0 + getBond() / 200.0);
                Vec3 look = rider.getLookAngle();
                Vec3 motion = getDeltaMovement().scale(0.91);
                if (input.z > 0) {
                    motion = motion.add(look.scale(speed * 0.12));
                } else {
                    motion = motion.add(0.0, -0.035, 0.0); // planear hacia abajo
                }
                if (input.x != 0) {
                    Vec3 right = new Vec3(-look.z, 0, look.x).normalize();
                    motion = motion.add(right.scale(-input.x * speed * 0.05));
                }
                double max = speed * 1.6;
                if (motion.length() > max) {
                    motion = motion.normalize().scale(max);
                }
                setDeltaMovement(motion);
                move(MoverType.SELF, getDeltaMovement());
                calculateEntityAnimation(true);
                resetFallDistance();
                return;
            }
        }
        super.travel(input);
    }

    @Override
    protected void removePassenger(Entity passenger) {
        super.removePassenger(passenger);
        if (passenger instanceof LivingEntity living && !onGround()) {
            living.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
        }
    }

    @Override
    public boolean isPushable() {
        return !isVehicle();
    }

    // ------------------------------------------------------------------ interacción
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean client = level().isClientSide;

        // Domesticar con rubí
        if (!isTame()) {
            if (stack.is(ModItems.RUBY.get())) {
                if (!client) {
                    stack.consume(1, player);
                    if (getRandom().nextFloat() < dragonType.tameChance) {
                        tame(player);
                        setTarget(null);
                        getNavigation().stop();
                        setOrderedToSit(false);
                        addBond(10);
                        level().broadcastEntityEvent(this, (byte) 7);
                        triggerAnim("action", "roar");
                        playSound(SoundEvents.ENDER_DRAGON_GROWL, 1.5f, 1.2f);
                        player.displayClientMessage(Component.translatable("msg.civilizacion_nether.tamed", getDisplayName()), true);
                    } else {
                        level().broadcastEntityEvent(this, (byte) 6);
                        player.displayClientMessage(Component.translatable("msg.civilizacion_nether.tame_fail", getDisplayName()), true);
                    }
                }
                return InteractionResult.sidedSuccess(client);
            }
            return super.mobInteract(player, hand);
        }

        if (!isOwnedBy(player)) {
            if (!client) {
                player.displayClientMessage(Component.translatable("msg.civilizacion_nether.not_owner"), true);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Reproducción / curación con chuleta asada
        if (isFood(stack)) {
            if (getHealth() < getMaxHealth() && !isInLove()) {
                if (!client) {
                    stack.consume(1, player);
                    heal(10.0f);
                    level().broadcastEntityEvent(this, (byte) 7);
                }
                return InteractionResult.sidedSuccess(client);
            }
            InteractionResult breed = super.mobInteract(player, hand);
            if (breed.consumesAction()) {
                return breed;
            }
        }

        // Entrenar: rubí sube el vínculo
        if (stack.is(ModItems.RUBY.get())) {
            if (!client) {
                stack.consume(1, player);
                addBond(5);
                heal(4.0f);
                level().broadcastEntityEvent(this, (byte) 7);
                player.displayClientMessage(Component.translatable("msg.civilizacion_nether.bond", getDisplayName(), getBond()), true);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Silla
        if (stack.is(Items.SADDLE) && !isSaddled() && !isBaby()) {
            if (!client) {
                stack.consume(1, player);
                entityData.set(SADDLED, true);
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.HORSE_SADDLE, SoundSource.NEUTRAL, 1.0f, 0.8f);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Armadura (opcional)
        if (stack.is(ModItems.DRAGON_ARMOR.get()) && !isArmored() && !isBaby()) {
            if (!client) {
                stack.consume(1, player);
                entityData.set(ARMORED, true);
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.ARMOR_EQUIP_NETHERITE.value(), SoundSource.NEUTRAL, 1.0f, 0.8f);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Mayús + clic: sentarse / seguir
        if (player.isSecondaryUseActive()) {
            if (!client) {
                boolean sit = !isOrderedToSit();
                setOrderedToSit(sit);
                setInSittingPose(sit);
                getNavigation().stop();
                setTarget(null);
                player.displayClientMessage(Component.translatable(
                        sit ? "msg.civilizacion_nether.sit" : "msg.civilizacion_nether.follow", getDisplayName()), true);
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Montar
        if (!isBaby()) {
            if (!isSaddled()) {
                if (!client) {
                    player.displayClientMessage(Component.translatable("msg.civilizacion_nether.need_saddle"), true);
                }
                return InteractionResult.sidedSuccess(client);
            }
            if (!client) {
                setOrderedToSit(false);
                setInSittingPose(false);
                player.setYRot(getYRot());
                player.setXRot(getXRot());
                player.startRiding(this);
                player.displayClientMessage(Component.translatable("msg.civilizacion_nether.ride_hint"), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return stack.is(Items.COOKED_PORKCHOP);
    }

    @Override
    public boolean canMate(Animal other) {
        return other != this && other instanceof NetherDragonEntity mate && mate.dragonType == dragonType
                && isTame() && mate.isTame() && isInLove() && mate.isInLove();
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        NetherDragonEntity baby = ModEntities.DRAGONS.get(dragonType).get().create(level);
        if (baby != null && getOwnerUUID() != null) {
            baby.setOwnerUUID(getOwnerUUID());
            baby.setTame(true, true);
            baby.addBond(20);
        }
        return baby;
    }

    // ------------------------------------------------------------------ guardado
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Saddled", isSaddled());
        tag.putBoolean("Armored", isArmored());
        tag.putInt("Bond", getBond());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(SADDLED, tag.getBoolean("Saddled"));
        entityData.set(ARMORED, tag.getBoolean("Armored"));
        entityData.set(BOND, tag.getInt("Bond"));
    }

    @Override
    protected void dropCustomDeathLoot(ServerLevel level, DamageSource source, boolean recentlyHit) {
        super.dropCustomDeathLoot(level, source, recentlyHit);
        if (isSaddled()) {
            spawnAtLocation(Items.SADDLE);
        }
        if (isArmored()) {
            spawnAtLocation(ModItems.DRAGON_ARMOR.get());
        }
    }

    // ------------------------------------------------------------------ sonidos
    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_GROWL;
    }

    @Override
    protected float getSoundVolume() {
        return 1.2f;
    }

    @Override
    public float getVoicePitch() {
        return isBaby() ? 1.6f : 1.0f + (getRandom().nextFloat() - 0.5f) * 0.2f;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 600;
    }

    // ------------------------------------------------------------------ GeckoLib
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 6, state -> {
            if (isInSittingPose()) {
                return state.setAndContinue(SIT);
            }
            if (!onGround() && !isInLava() && !isInWater()) {
                return state.setAndContinue(getDeltaMovement().y < -0.15 ? GLIDE : FLY);
            }
            if (state.isMoving()) {
                return state.setAndContinue(WALK);
            }
            return state.setAndContinue(IDLE);
        }));
        controllers.add(new AnimationController<>(this, "action", 3, state -> PlayState.STOP)
                .triggerableAnim("bite", RawAnimation.begin().thenPlay(P + "bite"))
                .triggerableAnim("breath", RawAnimation.begin().thenPlay(P + "breath"))
                .triggerableAnim("roar", RawAnimation.begin().thenPlay(P + "roar")));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }
}
