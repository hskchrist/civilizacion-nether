package com.civilizacionnether.entity.ai;

import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherHumanoidEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/**
 * Funciones de apoyo según el rol:
 * <ul>
 *   <li>Sacerdote: cura a los aliados heridos (el Supremo además da regeneración y resistencia).</li>
 *   <li>Noble: inspira a los aliados cercanos con fuerza mientras hay combate.</li>
 *   <li>Summoner: invoca almas del Nether cuando hay un enemigo.</li>
 * </ul>
 */
public class SupportGoal extends Goal {
    private final NetherHumanoidEntity mob;
    private int timer;

    public SupportGoal(NetherHumanoidEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.noneOf(Flag.class));
    }

    @Override
    public boolean canUse() {
        return !mob.isBaby() && --timer <= 0;
    }

    @Override
    public boolean canContinueToUse() {
        return false;
    }

    @Override
    public void start() {
        HumanoidType type = mob.getHumanoidType();
        switch (type.role) {
            case PRIEST -> timer = heal(type) ? 60 : 20;
            case NOBLE -> timer = rally() ? 240 : 40;
            case SUMMONER -> timer = summon() ? 320 : 40;
            default -> timer = 100;
        }
    }

    private List<LivingEntity> allies(double radius) {
        return mob.level().getEntitiesOfClass(LivingEntity.class, mob.getBoundingBox().inflate(radius),
                e -> e.isAlive() && NetherHumanoidEntity.isAlly(e) && !e.isSpectator());
    }

    private boolean heal(HumanoidType type) {
        boolean supreme = type == HumanoidType.SACERDOTE_SUPREMO;
        LivingEntity hurt = allies(supreme ? 12 : 8).stream()
                .filter(e -> e.getHealth() < e.getMaxHealth() - 1)
                .min(Comparator.comparingDouble(e -> e.getHealth() / e.getMaxHealth()))
                .orElse(null);
        if (hurt == null) {
            return false;
        }
        mob.getLookControl().setLookAt(hurt);
        mob.playAction("bless");
        mob.healAlly(hurt, supreme ? 8.0f : 4.0f);
        if (supreme) {
            for (LivingEntity e : allies(10)) {
                e.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0));
                e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
            }
        }
        return true;
    }

    private boolean rally() {
        List<LivingEntity> near = allies(12);
        boolean fighting = mob.getTarget() != null || near.stream().anyMatch(e -> e instanceof NetherHumanoidEntity h && h.getTarget() != null);
        if (!fighting) {
            return false;
        }
        mob.playAction("command");
        for (LivingEntity e : near) {
            e.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 240, 0));
            e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 240, 0));
        }
        return true;
    }

    private boolean summon() {
        LivingEntity target = mob.getTarget();
        if (target == null) {
            return false;
        }
        long souls = mob.level().getEntitiesOfClass(NetherHumanoidEntity.class, mob.getBoundingBox().inflate(16),
                e -> e.getHumanoidType() == HumanoidType.ALMA_NETHER).size();
        if (souls >= 4) {
            return false;
        }
        mob.summonSouls(target);
        return true;
    }
}
