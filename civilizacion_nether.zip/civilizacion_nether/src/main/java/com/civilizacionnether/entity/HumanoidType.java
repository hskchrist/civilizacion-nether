package com.civilizacionnether.entity;

import java.util.List;

/**
 * Los 15 tipos de humanos del Nether. El orden y los ids coinciden con las texturas
 * (textures/entity/&lt;id&gt;.png) y con los datos de spawn.
 */
public enum HumanoidType {
    //            id                    rol                vida  daño armad. veloc. combate                 cooldown huevo fondo/manchas
    CIVIL_COMUN("civil_comun", Role.CIVIL, 20, 3, 0, 0.30, Combat.MELEE, 22, 0x5A1418, 0xC8A040, List.of()),
    ALDEANO_NETHER("aldeano_nether", Role.MERCHANT, 22, 3, 0, 0.30, Combat.MELEE, 22, 0x7A341E, 0xD6A026, List.of("hood")),
    GUERRERO("guerrero", Role.WARRIOR, 34, 5, 6, 0.30, Combat.MELEE, 20, 0x2A2228, 0xD6A026, List.of("right_pauldron", "left_pauldron")),
    ARQUERO("arquero", Role.ARCHER, 26, 3, 2, 0.31, Combat.BOW, 40, 0x46101A, 0xEC4040, List.of("hood", "quiver")),
    MAGO("mago", Role.MAGE, 26, 7, 1, 0.29, Combat.SPELL, 45, 0x1E0A0E, 0xEC4040, List.of("hat_mago", "robe", "cape")),
    SUMMONER("summoner", Role.SUMMONER, 28, 5, 1, 0.29, Combat.SPELL, 50, 0x16080C, 0xFF8220, List.of("hat_summoner", "robe", "cape")),
    SACERDOTE("sacerdote", Role.PRIEST, 28, 5, 1, 0.29, Combat.SPELL, 50, 0x78141A, 0xD6A026, List.of("hood", "robe", "cape")),
    NOBLE("noble", Role.NOBLE, 40, 6, 4, 0.30, Combat.MELEE, 20, 0x1A0A0E, 0xFAD65C, List.of("crown", "robe", "cape")),
    GUARDIA_REAL("guardia_real", Role.WARRIOR, 50, 7, 10, 0.29, Combat.MELEE, 18, 0x68121A, 0xFAD65C, List.of("right_pauldron", "left_pauldron")),
    CABALLERO_RUBI("caballero_rubi", Role.KNIGHT, 50, 8, 10, 0.30, Combat.MELEE, 18, 0x420C12, 0xEC4040, List.of("right_pauldron", "left_pauldron", "cape")),
    ARQUERO_ELITE("arquero_elite", Role.ARCHER, 34, 5, 4, 0.32, Combat.BOW, 25, 0x240A0E, 0xFF5A1E, List.of("hood", "quiver", "cape")),
    MAGO_BATALLA("mago_batalla", Role.MAGE, 40, 8, 6, 0.30, Combat.SPELL_MELEE, 30, 0x3C0E12, 0xD6A026, List.of("right_pauldron", "left_pauldron", "robe", "cape")),
    BERSERKER("berserker", Role.BERSERKER, 44, 8, 2, 0.34, Combat.MELEE, 14, 0x744230, 0xA81E1E, List.of("right_pauldron", "left_pauldron")),
    SACERDOTE_SUPREMO("sacerdote_supremo", Role.PRIEST, 60, 8, 8, 0.29, Combat.SPELL, 35, 0x8C1020, 0xFFDC5A, List.of("right_pauldron", "left_pauldron", "crown", "robe", "cape")),
    ALMA_NETHER("alma_nether", Role.SOUL, 14, 5, 0, 0.34, Combat.MELEE, 20, 0x2878A5, 0xD2F5FF, List.of());

    public static final List<String> OPTIONAL_BONES = List.of(
            "crown", "hat_mago", "hat_summoner", "hood", "cape", "robe", "quiver", "right_pauldron", "left_pauldron");

    public enum Role { CIVIL, MERCHANT, WARRIOR, ARCHER, MAGE, SUMMONER, PRIEST, NOBLE, KNIGHT, BERSERKER, SOUL }

    public enum Combat { MELEE, BOW, SPELL, SPELL_MELEE }

    public final String id;
    public final Role role;
    public final double health;
    public final double damage;
    public final double armor;
    public final double speed;
    public final Combat combat;
    public final int attackCooldown;
    public final int eggBackground;
    public final int eggSpots;
    public final List<String> visibleBones;

    HumanoidType(String id, Role role, double health, double damage, double armor, double speed, Combat combat,
                 int attackCooldown, int eggBackground, int eggSpots, List<String> visibleBones) {
        this.id = id;
        this.role = role;
        this.health = health;
        this.damage = damage;
        this.armor = armor;
        this.speed = speed;
        this.combat = combat;
        this.attackCooldown = attackCooldown;
        this.eggBackground = eggBackground;
        this.eggSpots = eggSpots;
        this.visibleBones = visibleBones;
    }

    public boolean isElite() {
        return this == GUARDIA_REAL || this == CABALLERO_RUBI || this == ARQUERO_ELITE || this == MAGO_BATALLA
                || this == BERSERKER || this == SACERDOTE_SUPREMO;
    }

    /** Animación de reposo propia de cada tipo. */
    public String idleAnimation() {
        return switch (this) {
            case GUERRERO, GUARDIA_REAL, CABALLERO_RUBI, ARQUERO_ELITE -> "idle_guard";
            case BERSERKER -> "idle_berserk";
            default -> "idle";
        };
    }
}
