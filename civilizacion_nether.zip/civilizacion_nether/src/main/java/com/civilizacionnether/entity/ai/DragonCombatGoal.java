package com.civilizacionnether.entity.ai;

import com.civilizacionnether.entity.NetherDragonEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;

/** Combate del dragón cuando no lo monta nadie: mordida de cerca y aliento a media distancia. */
public class DragonCombatGoal extends Goal {
    private final NetherDragonEntity dragon;
    private int biteCooldown;
    private int repath;

    public DragonCombatGoal(NetherDragonEntity dragon) {
        this.dragon = dragon;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        LivingEntity target = dragon.getTarget();
        return target != null && target.isAlive() && !dragon.isOrderedToSit() && !dragon.isVehicle();
    }

    @Override
    public void start() {
        dragon.setAggressive(true);
        repath = 0;
    }

    @Override
    public void stop() {
        dragon.setAggressive(false);
        dragon.getNavigation().stop();
    }

    @Override
    public boolean requiresUpdateEveryTick() {
        return true;
    }

    @Override
    public void tick() {
        LivingEntity target = dragon.getTarget();
        if (target == null) {
            return;
        }
        dragon.getLookControl().setLookAt(target, 20.0f, 20.0f);
        double distSq = dragon.distanceToSqr(target);
        double reach = dragon.getBbWidth() * 0.9 + target.getBbWidth() + 1.5;
        boolean sees = dragon.getSensing().hasLineOfSight(target);
        if (biteCooldown > 0) {
            biteCooldown--;
        }
        if (--repath <= 0) {
            repath = 10;
            dragon.getNavigation().moveTo(target, 1.15);
        }
        if (distSq <= reach * reach) {
            if (biteCooldown <= 0) {
                biteCooldown = 24;
                dragon.bite(target);
            }
        } else if (sees && distSq < 14 * 14 && dragon.canBreathe() && dragon.getRandom().nextInt(25) == 0) {
            dragon.startBreath();
        }
    }
}
