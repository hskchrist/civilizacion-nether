package com.civilizacionnether.entity.ai;

import com.civilizacionnether.entity.NetherHumanoidEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.state.BlockState;

import java.util.EnumSet;

/** El civil común cosecha la verruga del Nether madura y la vuelve a plantar ("Agricultura en el Nether"). */
public class HarvestWartGoal extends Goal {
    private final NetherHumanoidEntity mob;
    private BlockPos targetPos;
    private int timeout;

    public HarvestWartGoal(NetherHumanoidEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (mob.getTarget() != null || mob.isOrderedToSit() || mob.isBaby() || mob.getRandom().nextInt(80) != 0) {
            return false;
        }
        if (!mob.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
            return false;
        }
        BlockPos origin = mob.blockPosition();
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-8, -2, -8), origin.offset(8, 2, 8))) {
            BlockState state = mob.level().getBlockState(pos);
            if (state.is(Blocks.NETHER_WART) && state.getValue(NetherWartBlock.AGE) >= NetherWartBlock.MAX_AGE) {
                targetPos = pos.immutable();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean canContinueToUse() {
        return targetPos != null && timeout > 0 && mob.getTarget() == null;
    }

    @Override
    public void start() {
        timeout = 200;
        mob.getNavigation().moveTo(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5, 0.9);
    }

    @Override
    public void stop() {
        targetPos = null;
    }

    @Override
    public void tick() {
        timeout--;
        mob.getLookControl().setLookAt(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5);
        if (mob.blockPosition().distSqr(targetPos) <= 4.0) {
            BlockState state = mob.level().getBlockState(targetPos);
            if (state.is(Blocks.NETHER_WART) && state.getValue(NetherWartBlock.AGE) >= NetherWartBlock.MAX_AGE) {
                mob.playAction("work_farm");
                mob.level().destroyBlock(targetPos, true, mob);
                if (mob.level().getBlockState(targetPos.below()).is(Blocks.SOUL_SAND)) {
                    mob.level().setBlockAndUpdate(targetPos, Blocks.NETHER_WART.defaultBlockState());
                }
            }
            targetPos = null;
        } else if (mob.getNavigation().isDone()) {
            mob.getNavigation().moveTo(targetPos.getX() + 0.5, targetPos.getY(), targetPos.getZ() + 0.5, 0.9);
        }
    }
}
