package com.civilizacionnether.entity;

import com.civilizacionnether.entity.ai.FollowOwnerSimpleGoal;
import com.civilizacionnether.entity.ai.HarvestWartGoal;
import com.civilizacionnether.entity.ai.HumanoidCombatGoal;
import com.civilizacionnether.entity.ai.SupportGoal;
import com.civilizacionnether.registry.ModEntities;
import com.civilizacionnether.registry.ModItems;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.animal.AbstractGolem;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.animal.horse.Horse;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.ItemCost;
import net.minecraft.world.item.trading.Merchant;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.PlayState;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.Optional;

/**
 * Humano del Nether. Una sola clase para los 15 tipos; el {@link HumanoidType} decide vida, armas,
 * forma de combate, piezas visibles del modelo y animaciones.
 * <ul>
 *   <li>Aliados del jugador, aldeanos, golems y todos sus aliados; atacan a los mobs hostiles.</li>
 *   <li>Se domestican con varas de blaze y se reproducen con chuleta de cerdo asada.</li>
 * </ul>
 */
public class NetherHumanoidEntity extends TamableAnimal implements GeoEntity, Merchant {
    private static final String P = "animation.nether_humanoid.";
    public static final RawAnimation WALK = RawAnimation.begin().thenLoop(P + "walk");
    public static final RawAnimation RUN = RawAnimation.begin().thenLoop(P + "run");
    public static final RawAnimation SIT = RawAnimation.begin().thenLoop(P + "sit");
    public static final RawAnimation RIDE = RawAnimation.begin().thenLoop(P + "ride");

    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);
    private final HumanoidType humanoidType;
    private final RawAnimation idleAnimation;

    @Nullable
    private Player tradingPlayer;
    @Nullable
    private MerchantOffers offers;
    private int lifeTicks = -1; // solo las almas invocadas
    private int restockTimer;

    public NetherHumanoidEntity(EntityType<? extends TamableAnimal> entityType, Level level, HumanoidType type) {
        super(entityType, level);
        this.humanoidType = type;
        this.idleAnimation = RawAnimation.begin().thenLoop(P + type.idleAnimation());
        this.xpReward = type.isElite() ? 12 : 5;
        equipDefaults();
        addTypeGoals();
    }

    public HumanoidType getHumanoidType() {
        return humanoidType;
    }

    public static AttributeSupplier.Builder createAttributes(HumanoidType type) {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, type.health)
                .add(Attributes.ATTACK_DAMAGE, type.damage)
                .add(Attributes.ARMOR, type.armor)
                .add(Attributes.MOVEMENT_SPEED, type.speed)
                .add(Attributes.FOLLOW_RANGE, 32.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, type.isElite() ? 0.4 : 0.1);
    }

    // ------------------------------------------------------------------ equipo
    private void equipDefaults() {
        ItemStack main = switch (humanoidType) {
            case GUERRERO, NOBLE, GUARDIA_REAL, CABALLERO_RUBI, BERSERKER -> new ItemStack(ModItems.RUBY_SWORD.get());
            case ARQUERO, ARQUERO_ELITE -> new ItemStack(ModItems.RUBY_BOW.get());
            case MAGO, SUMMONER, SACERDOTE, MAGO_BATALLA, SACERDOTE_SUPREMO -> new ItemStack(ModItems.RUBY_STAFF.get());
            case ALDEANO_NETHER -> new ItemStack(ModItems.RUBY.get());
            case CIVIL_COMUN -> new ItemStack(Items.GOLDEN_HOE);
            case ALMA_NETHER -> ItemStack.EMPTY;
        };
        ItemStack off = switch (humanoidType) {
            case GUARDIA_REAL -> new ItemStack(Items.SHIELD);
            case BERSERKER -> new ItemStack(ModItems.RUBY_SWORD.get());
            default -> ItemStack.EMPTY;
        };
        setItemSlot(EquipmentSlot.MAINHAND, main);
        setItemSlot(EquipmentSlot.OFFHAND, off);
        setDropChance(EquipmentSlot.MAINHAND, 0.0f);
        setDropChance(EquipmentSlot.OFFHAND, 0.0f);
    }

    // ------------------------------------------------------------------ IA
    @Override
    protected void registerGoals() {
        // Comunes a todos (el tipo aún no existe aquí; lo específico va en addTypeGoals)
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new HumanoidCombatGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerSimpleGoal(this, 1.15, 10.0, 3.0));
        this.goalSelector.addGoal(5, new BreedGoal(this, 1.0));
        this.goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));

        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this, Player.class, NetherHumanoidEntity.class,
                NetherDragonEntity.class, AbstractGolem.class, AbstractVillager.class, AbstractHorse.class).setAlertOthers());
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false,
                NetherHumanoidEntity::isHostileTarget));
    }

    private void addTypeGoals() {
        switch (humanoidType.role) {
            case PRIEST, NOBLE, SUMMONER -> this.goalSelector.addGoal(3, new SupportGoal(this));
            case CIVIL -> this.goalSelector.addGoal(6, new HarvestWartGoal(this));
            default -> {
            }
        }
    }

    /** Mobs hostiles a los que atacan por iniciativa propia. Los neutrales solo si están enojados. */
    public static boolean isHostileTarget(LivingEntity e) {
        if (!(e instanceof Enemy) || !e.isAlive()) {
            return false;
        }
        if (e instanceof NeutralMob neutral) {
            return neutral.isAngry();
        }
        return true;
    }

    /** Aliados: el jugador, aldeanos, golems, caballos, la civilización y los dragones. */
    public static boolean isAlly(LivingEntity e) {
        return e instanceof Player || e instanceof AbstractVillager || e instanceof AbstractGolem
                || e instanceof NetherHumanoidEntity || e instanceof NetherDragonEntity || e instanceof AbstractHorse
                || (e instanceof TamableAnimal t && t.isTame());
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (isAlly(target)) {
            return false;
        }
        return super.canAttack(target);
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        return !isAlly(target);
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        // Sin fuego amigo: los aliados no se dañan entre sí (flechas, rayos, alientos).
        Entity attacker = source.getEntity();
        if (attacker instanceof NetherHumanoidEntity || attacker instanceof NetherDragonEntity
                || attacker instanceof AbstractGolem || attacker instanceof AbstractVillager) {
            return false;
        }
        if (isOrderedToSit() && attacker != null && !(attacker instanceof Player)) {
            setOrderedToSit(false);
        }
        return super.hurt(source, amount);
    }

    // ------------------------------------------------------------------ ataques
    public void playAction(String name) {
        triggerAnim("action", name);
    }

    public void performMelee(LivingEntity target) {
        swing(InteractionHand.MAIN_HAND);
        playAction(humanoidType == HumanoidType.BERSERKER ? "attack_berserk" : "attack_melee");
        if (doHurtTarget(target) && humanoidType == HumanoidType.BERSERKER) {
            // Furia: golpe doble y empuje
            target.invulnerableTime = 0;
            target.hurt(damageSources().mobAttack(this), (float) humanoidType.damage * 0.5f);
            target.knockback(0.6, getX() - target.getX(), getZ() - target.getZ());
        }
        if (humanoidType == HumanoidType.NOBLE || humanoidType == HumanoidType.CABALLERO_RUBI) {
            target.setRemainingFireTicks(40);
        }
    }

    public void shootArrow(LivingEntity target) {
        Arrow arrow = EntityType.ARROW.create(level());
        if (arrow == null) {
            return;
        }
        arrow.setOwner(this);
        arrow.setPos(getX(), getEyeY() - 0.15, getZ());
        double dx = target.getX() - getX();
        double dy = target.getY(0.3333) - arrow.getY();
        double dz = target.getZ() - getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        boolean elite = humanoidType == HumanoidType.ARQUERO_ELITE;
        arrow.shoot(dx, dy + horizontal * 0.2, dz, elite ? 2.2f : 1.8f, elite ? 2.0f : 6.0f);
        arrow.setBaseDamage(humanoidType.damage * 0.55);
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        if (elite) {
            arrow.setRemainingFireTicks(100);
            arrow.setCritArrow(true);
        }
        level().addFreshEntity(arrow);
        playSound(SoundEvents.SKELETON_SHOOT, 1.0f, 1.0f / (getRandom().nextFloat() * 0.4f + 0.8f));
    }

    /** Rayo mágico instantáneo con partículas, sin dañar bloques. */
    public void castBolt(LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) {
            return;
        }
        ParticleOptions particle = switch (humanoidType) {
            case SUMMONER -> ParticleTypes.SOUL_FIRE_FLAME;
            case SACERDOTE, SACERDOTE_SUPREMO -> ParticleTypes.END_ROD;
            default -> ParticleTypes.FLAME;
        };
        Vec3 from = new Vec3(getX(), getEyeY() - 0.3, getZ());
        Vec3 to = target.getBoundingBox().getCenter();
        Vec3 dir = to.subtract(from);
        int steps = (int) Math.max(4, dir.length() * 2.5);
        for (int i = 1; i <= steps; i++) {
            Vec3 p = from.add(dir.scale(i / (double) steps));
            server.sendParticles(particle, p.x, p.y, p.z, 1, 0.03, 0.03, 0.03, 0.0);
        }
        server.sendParticles(ParticleTypes.CRIMSON_SPORE, to.x, to.y, to.z, 8, 0.3, 0.3, 0.3, 0.02);
        target.hurt(damageSources().indirectMagic(this, this), (float) humanoidType.damage);
        if (particle == ParticleTypes.FLAME) {
            target.setRemainingFireTicks(60);
        }
        playSound(SoundEvents.BLAZE_SHOOT, 0.7f, 1.4f);
    }

    /** Summoner: invoca almas del Nether aliadas durante 30 segundos. */
    public void summonSouls(@Nullable LivingEntity target) {
        if (!(level() instanceof ServerLevel server)) {
            return;
        }
        playAction("summon");
        int count = humanoidType == HumanoidType.SUMMONER ? 2 : 1;
        for (int i = 0; i < count; i++) {
            NetherHumanoidEntity soul = ModEntities.humanoid(HumanoidType.ALMA_NETHER).create(server);
            if (soul == null) {
                continue;
            }
            double ox = (getRandom().nextDouble() - 0.5) * 4;
            double oz = (getRandom().nextDouble() - 0.5) * 4;
            soul.moveTo(getX() + ox, getY(), getZ() + oz, getYRot(), 0);
            soul.lifeTicks = 600;
            if (isTame() && getOwnerUUID() != null) {
                soul.setOwnerUUID(getOwnerUUID());
                soul.setTame(true, false);
            }
            if (target != null) {
                soul.setTarget(target);
            }
            server.addFreshEntity(soul);
            server.sendParticles(ParticleTypes.SOUL, soul.getX(), soul.getY() + 1, soul.getZ(), 20, 0.4, 0.8, 0.4, 0.02);
        }
        playSound(SoundEvents.EVOKER_PREPARE_SUMMON, 1.0f, 1.0f);
    }

    // ------------------------------------------------------------------ ciclo de vida
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            if (humanoidType == HumanoidType.ALMA_NETHER && getRandom().nextInt(3) == 0) {
                level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0.02, 0);
            }
            return;
        }
        if (lifeTicks > 0 && --lifeTicks == 0) {
            if (level() instanceof ServerLevel server) {
                server.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1, getZ(), 15, 0.3, 0.6, 0.3, 0.02);
            }
            discard();
            return;
        }
        if (humanoidType.role == HumanoidType.Role.MERCHANT && ++restockTimer > 6000) {
            restockTimer = 0;
            if (offers != null) {
                offers.forEach(MerchantOffer::resetUses);
            }
        }
        // vida cotidiana: animaciones de oficio cuando están tranquilos
        if (getTarget() == null && getNavigation().isDone() && !isInSittingPose() && getRandom().nextInt(500) == 0) {
            String anim = switch (humanoidType.role) {
                case CIVIL -> getRandom().nextBoolean() ? "work_farm" : "forge";
                case MERCHANT -> "trade";
                case PRIEST -> "pray";
                case NOBLE -> "command";
                case MAGE, SUMMONER -> "ritual";
                default -> null;
            };
            if (anim != null) {
                playAction(anim);
            }
        }
    }

    /** Permite aparecer y moverse en la oscuridad del Nether (los animales normales necesitan luz o pasto). */
    @Override
    public float getWalkTargetValue(net.minecraft.core.BlockPos pos, net.minecraft.world.level.LevelReader level) {
        return 0.0f;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType spawnType,
                                        @Nullable SpawnGroupData groupData) {
        SpawnGroupData data = super.finalizeSpawn(level, difficulty, spawnType, groupData);
        if (humanoidType == HumanoidType.CABALLERO_RUBI && !isBaby()) {
            // El Caballero del Rubí aparece montado en su caballo con armadura de oro
            Horse horse = EntityType.HORSE.create(level.getLevel());
            if (horse != null) {
                horse.moveTo(getX(), getY(), getZ(), getYRot(), 0.0f);
                horse.finalizeSpawn(level, difficulty, MobSpawnType.JOCKEY, null);
                horse.setTamed(true);
                horse.setAge(0);
                horse.equipSaddle(new ItemStack(Items.SADDLE), null);
                horse.setBodyArmorItem(new ItemStack(Items.GOLDEN_HORSE_ARMOR));
                horse.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, MobEffectInstance.INFINITE_DURATION, 0, false, false));
                horse.setPersistenceRequired();
                level.addFreshEntity(horse);
                this.startRiding(horse, true);
            }
        }
        return data;
    }

    // ------------------------------------------------------------------ interacción
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (humanoidType == HumanoidType.ALMA_NETHER) {
            return InteractionResult.PASS;
        }
        boolean client = level().isClientSide;

        // Domesticar: varas de blaze
        if (!isTame() && stack.is(Items.BLAZE_ROD)) {
            if (!client) {
                stack.consume(1, player);
                int chance = humanoidType.isElite() ? 5 : 3;
                if (getRandom().nextInt(chance) == 0) {
                    tame(player);
                    getNavigation().stop();
                    setTarget(null);
                    setOrderedToSit(false);
                    level().broadcastEntityEvent(this, (byte) 7);
                    playAction("tamed");
                    player.displayClientMessage(Component.translatable("msg.civilizacion_nether.tamed", getDisplayName()), true);
                } else {
                    level().broadcastEntityEvent(this, (byte) 6);
                    player.displayClientMessage(Component.translatable("msg.civilizacion_nether.tame_fail", getDisplayName()), true);
                }
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Reproducción (y curación si ya es tuyo): chuleta de cerdo asada
        if (isFood(stack)) {
            if (isTame() && getHealth() < getMaxHealth() && !isInLove()) {
                if (!client) {
                    stack.consume(1, player);
                    heal(6.0f);
                    level().broadcastEntityEvent(this, (byte) 7);
                }
                return InteractionResult.sidedSuccess(client);
            }
            InteractionResult breed = super.mobInteract(player, hand);
            if (breed.consumesAction()) {
                return breed;
            }
        }

        // Comercio con el Aldeano del Nether
        if (humanoidType.role == HumanoidType.Role.MERCHANT && !player.isSecondaryUseActive() && !isBaby()) {
            if (!client && tradingPlayer == null && !getOffers().isEmpty()) {
                setTradingPlayer(player);
                openTradingScreen(player, getDisplayName(), 1);
                playAction("trade");
            }
            return InteractionResult.sidedSuccess(client);
        }

        // Sentarse / seguir (dueño, clic derecho; el aldeano usa Mayús + clic)
        if (isTame() && isOwnedBy(player)) {
            if (!client) {
                boolean sit = !isOrderedToSit();
                setOrderedToSit(sit);
                setInSittingPose(sit);
                getNavigation().stop();
                setTarget(null);
                player.displayClientMessage(Component.translatable(
                        sit ? "msg.civilizacion_nether.sit" : "msg.civilizacion_nether.follow", getDisplayName()), true);
            }
            return InteractionResult.sidedSuccess(client);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return humanoidType != HumanoidType.ALMA_NETHER && stack.is(Items.COOKED_PORKCHOP);
    }

    @Override
    public boolean canMate(Animal other) {
        return other != this && other instanceof NetherHumanoidEntity mate
                && mate.humanoidType == this.humanoidType && isInLove() && mate.isInLove()
                && !isOrderedToSit() && !mate.isOrderedToSit();
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob otherParent) {
        NetherHumanoidEntity baby = ModEntities.humanoid(humanoidType).create(level);
        if (baby != null && isTame() && getOwnerUUID() != null) {
            baby.setOwnerUUID(getOwnerUUID());
            baby.setTame(true, true);
        }
        return baby;
    }

    // ------------------------------------------------------------------ guardado
    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("LifeTicks", lifeTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("LifeTicks")) {
            lifeTicks = tag.getInt("LifeTicks");
        }
    }

    // ------------------------------------------------------------------ sonidos
    @Override
    protected SoundEvent getAmbientSound() {
        return humanoidType == HumanoidType.ALMA_NETHER ? SoundEvents.VEX_AMBIENT : SoundEvents.PIGLIN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PLAYER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PLAYER_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return isBaby() ? 1.5f : 0.75f + getRandom().nextFloat() * 0.1f;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 400;
    }

    // ------------------------------------------------------------------ comercio (Merchant)
    @Override
    public void setTradingPlayer(@Nullable Player player) {
        this.tradingPlayer = player;
    }

    @Nullable
    @Override
    public Player getTradingPlayer() {
        return tradingPlayer;
    }

    @Override
    public MerchantOffers getOffers() {
        if (offers == null) {
            offers = new MerchantOffers();
            if (humanoidType.role == HumanoidType.Role.MERCHANT) {
                offers.add(offer(Items.GOLD_INGOT, 4, new ItemStack(ModItems.RUBY.get()), 16));
                offers.add(offer(Items.QUARTZ, 16, new ItemStack(ModItems.RUBY.get()), 12));
                offers.add(offer(ModItems.RUBY.get(), 1, new ItemStack(Items.BLAZE_ROD, 2), 16));
                offers.add(offer(ModItems.RUBY.get(), 1, new ItemStack(Items.COOKED_PORKCHOP, 6), 16));
                offers.add(offer(ModItems.RUBY.get(), 2, new ItemStack(Items.NETHER_WART, 12), 12));
                offers.add(offer(ModItems.RUBY.get(), 3, new ItemStack(ModItems.RUBY_LAMP.get(), 4), 12));
                offers.add(offer(ModItems.RUBY.get(), 5, new ItemStack(Items.SADDLE), 4));
                offers.add(offer(ModItems.RUBY.get(), 8, new ItemStack(ModItems.RUBY_SWORD.get()), 3));
                offers.add(offer(ModItems.RUBY.get(), 10, new ItemStack(ModItems.RUBY_BOW.get()), 3));
                offers.add(offer(ModItems.RUBY.get(), 12, new ItemStack(ModItems.RUBY_STAFF.get()), 2));
                offers.add(offer(ModItems.RUBY.get(), 20, new ItemStack(ModItems.DRAGON_ARMOR.get()), 1));
            }
        }
        return offers;
    }

    private static MerchantOffer offer(net.minecraft.world.level.ItemLike cost, int count, ItemStack result, int maxUses) {
        return new MerchantOffer(new ItemCost(cost, count), Optional.empty(), result, maxUses, 2, 0.05f);
    }

    @Override
    public void overrideOffers(MerchantOffers newOffers) {
        this.offers = newOffers;
    }

    @Override
    public void notifyTrade(MerchantOffer offer) {
        offer.increaseUses();
        this.ambientSoundTime = -getAmbientSoundInterval();
        playSound(SoundEvents.VILLAGER_YES, 1.0f, 0.8f);
        playAction("trade");
    }

    @Override
    public void notifyTradeUpdated(ItemStack stack) {
        if (!level().isClientSide && this.ambientSoundTime > -getAmbientSoundInterval() + 20) {
            this.ambientSoundTime = -getAmbientSoundInterval();
            playSound(stack.isEmpty() ? SoundEvents.VILLAGER_NO : SoundEvents.VILLAGER_YES, 1.0f, 0.8f);
        }
    }

    @Override
    public int getVillagerXp() {
        return 0;
    }

    @Override
    public void overrideXp(int xp) {
    }

    @Override
    public boolean showProgressBar() {
        return false;
    }

    @Override
    public SoundEvent getNotifyTradeSound() {
        return SoundEvents.VILLAGER_YES;
    }

    @Override
    public boolean isClientSide() {
        return level().isClientSide;
    }

    // ------------------------------------------------------------------ GeckoLib
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "movement", 4, state -> {
            if (isInSittingPose()) {
                return state.setAndContinue(SIT);
            }
            if (isPassenger()) {
                return state.setAndContinue(RIDE);
            }
            if (state.isMoving()) {
                return state.setAndContinue(isAggressive() ? RUN : WALK);
            }
            return state.setAndContinue(idleAnimation);
        }));
        AnimationController<NetherHumanoidEntity> action = new AnimationController<>(this, "action", 2, state -> PlayState.STOP);
        for (String name : new String[]{"attack_melee", "attack_berserk", "attack_bow", "attack_spell", "summon", "bless",
                "work_farm", "forge", "pray", "command", "ritual", "trade", "tamed"}) {
            action.triggerableAnim(name, RawAnimation.begin().thenPlay(P + name));
        }
        controllers.add(action);
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return geoCache;
    }

    // utilidades para la IA
    public void healAlly(LivingEntity ally, float amount) {
        ally.heal(amount);
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.HEART, ally.getX(), ally.getY() + ally.getBbHeight(), ally.getZ(), 3, 0.3, 0.2, 0.3, 0.0);
        }
    }
}
