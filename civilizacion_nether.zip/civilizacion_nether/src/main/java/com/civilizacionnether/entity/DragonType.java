package com.civilizacionnether.entity;

/** Los cuatro dragones del Nether y sus diferencias (imagen "Dragones del Nether"). */
public enum DragonType {
    //          id                  vida  mordida armad. veloc. vuelo  aliento prob. domar  huevo fondo/manchas
    RUBI("dragon_rubi", 160, 12, 10, 0.26, 0.60, 7.0f, 0.50f, 0x960E18, 0xFF4650),       // raro, fuego de rubí, el más dócil
    OBSIDIANA("dragon_obsidiana", 200, 11, 18, 0.23, 0.52, 6.0f, 0.25f, 0x1A1620, 0x7828A0), // común, fuego de obsidiana, gran resistencia
    FUEGO("dragon_fuego", 180, 15, 8, 0.25, 0.60, 10.0f, 0.15f, 0x2C120E, 0xFF7814),        // poco común, fuego de lava, alto daño
    HUESO("dragon_hueso", 140, 11, 6, 0.30, 0.80, 7.0f, 0.20f, 0xCEC8BA, 0x9C1A22);          // raro, fuego espectral, velocidad y agilidad

    public final String id;
    public final double health;
    public final double biteDamage;
    public final double armor;
    public final double speed;
    public final double flyingSpeed;
    public final float breathDamage;
    public final float tameChance;
    public final int eggBackground;
    public final int eggSpots;

    DragonType(String id, double health, double biteDamage, double armor, double speed, double flyingSpeed,
               float breathDamage, float tameChance, int eggBackground, int eggSpots) {
        this.id = id;
        this.health = health;
        this.biteDamage = biteDamage;
        this.armor = armor;
        this.speed = speed;
        this.flyingSpeed = flyingSpeed;
        this.breathDamage = breathDamage;
        this.tameChance = tameChance;
        this.eggBackground = eggBackground;
        this.eggSpots = eggSpots;
    }
}
