package com.civilizacionnether.event;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.DragonType;
import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherDragonEntity;
import com.civilizacionnether.entity.NetherHumanoidEntity;
import com.civilizacionnether.network.DragonBreathPayload;
import com.civilizacionnether.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

@EventBusSubscriber(modid = CivilizacionNether.MODID, bus = EventBusSubscriber.Bus.MOD)
public final class CommonEvents {

    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        for (HumanoidType type : HumanoidType.values()) {
            event.put(ModEntities.HUMANOIDS.get(type).get(), NetherHumanoidEntity.createAttributes(type).build());
        }
        for (DragonType type : DragonType.values()) {
            event.put(ModEntities.DRAGONS.get(type).get(), NetherDragonEntity.createAttributes(type).build());
        }
    }

    @SubscribeEvent
    public static void spawnPlacements(RegisterSpawnPlacementsEvent event) {
        for (HumanoidType type : HumanoidType.values()) {
            event.register(ModEntities.HUMANOIDS.get(type).get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CommonEvents::canSpawnHumanoid,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
        }
        for (DragonType type : DragonType.values()) {
            event.register(ModEntities.DRAGONS.get(type).get(), SpawnPlacementTypes.ON_GROUND,
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CommonEvents::canSpawnDragon,
                    RegisterSpawnPlacementsEvent.Operation.REPLACE);
        }
    }

    private static boolean canSpawnHumanoid(EntityType<NetherHumanoidEntity> type, ServerLevelAccessor level,
                                            MobSpawnType reason, BlockPos pos, RandomSource random) {
        BlockPos below = pos.below();
        return level.getBlockState(below).isValidSpawn(level, below, type) && !level.getBlockState(below).liquid();
    }

    private static boolean canSpawnDragon(EntityType<NetherDragonEntity> type, ServerLevelAccessor level,
                                          MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (reason == MobSpawnType.NATURAL && random.nextInt(4) != 0) {
            return false; // los dragones son escasos
        }
        BlockPos below = pos.below();
        return level.getBlockState(below).isValidSpawn(level, below, type) && !level.getBlockState(below).liquid();
    }

    @SubscribeEvent
    public static void payloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(DragonBreathPayload.TYPE, DragonBreathPayload.STREAM_CODEC, DragonBreathPayload::handle);
    }

    private CommonEvents() {
    }
}
