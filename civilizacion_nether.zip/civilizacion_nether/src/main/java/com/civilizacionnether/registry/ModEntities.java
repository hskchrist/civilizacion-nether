package com.civilizacionnether.registry;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.DragonType;
import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherDragonEntity;
import com.civilizacionnether.entity.NetherHumanoidEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, CivilizacionNether.MODID);

    /** Un EntityType por cada tipo humano: misma clase, distinta configuración. */
    public static final Map<HumanoidType, DeferredHolder<EntityType<?>, EntityType<NetherHumanoidEntity>>> HUMANOIDS =
            new EnumMap<>(HumanoidType.class);
    public static final Map<DragonType, DeferredHolder<EntityType<?>, EntityType<NetherDragonEntity>>> DRAGONS =
            new EnumMap<>(DragonType.class);

    static {
        for (HumanoidType type : HumanoidType.values()) {
            // Misma altura y ancho que el Wither Skeleton (0,7 x 2,4 bloques)
            HUMANOIDS.put(type, ENTITIES.register(type.id, () -> EntityType.Builder
                    .<NetherHumanoidEntity>of((entityType, level) -> new NetherHumanoidEntity(entityType, level, type), MobCategory.CREATURE)
                    .sized(0.7f, 2.4f)
                    .eyeHeight(2.1f)
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build(type.id)));
        }
        for (DragonType type : DragonType.values()) {
            DRAGONS.put(type, ENTITIES.register(type.id, () -> EntityType.Builder
                    .<NetherDragonEntity>of((entityType, level) -> new NetherDragonEntity(entityType, level, type), MobCategory.CREATURE)
                    .sized(4.0f, 3.6f)
                    .eyeHeight(3.2f)
                    .passengerAttachments(new Vec3(0.0, 3.35, 0.55))
                    .fireImmune()
                    .clientTrackingRange(16)
                    .build(type.id)));
        }
    }

    public static EntityType<NetherHumanoidEntity> humanoid(HumanoidType type) {
        return HUMANOIDS.get(type).get();
    }

    private ModEntities() {
    }
}
