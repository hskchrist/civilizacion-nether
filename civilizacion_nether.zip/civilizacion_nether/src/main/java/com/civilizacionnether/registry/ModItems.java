package com.civilizacionnether.registry;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.DragonType;
import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.item.DragonArmorItem;
import com.civilizacionnether.item.RubyStaffItem;
import com.civilizacionnether.item.RubyTier;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(CivilizacionNether.MODID);

    public static final DeferredItem<Item> RUBY = ITEMS.register("ruby", () -> new Item(new Item.Properties()));

    public static final DeferredItem<SwordItem> RUBY_SWORD = ITEMS.register("ruby_sword", () -> new SwordItem(RubyTier.INSTANCE,
            new Item.Properties().attributes(SwordItem.createAttributes(RubyTier.INSTANCE, 3, -2.4f))));

    public static final DeferredItem<RubyStaffItem> RUBY_STAFF = ITEMS.register("ruby_staff",
            () -> new RubyStaffItem(new Item.Properties().durability(500).rarity(Rarity.UNCOMMON)));

    public static final DeferredItem<BowItem> RUBY_BOW = ITEMS.register("ruby_bow",
            () -> new BowItem(new Item.Properties().durability(640)));

    public static final DeferredItem<ArmorItem> RUBY_HELMET = ITEMS.register("ruby_helmet", () -> new ArmorItem(
            ModArmorMaterials.RUBY, ArmorItem.Type.HELMET, new Item.Properties().durability(ArmorItem.Type.HELMET.getDurability(35))));
    public static final DeferredItem<ArmorItem> RUBY_CHESTPLATE = ITEMS.register("ruby_chestplate", () -> new ArmorItem(
            ModArmorMaterials.RUBY, ArmorItem.Type.CHESTPLATE, new Item.Properties().durability(ArmorItem.Type.CHESTPLATE.getDurability(35))));
    public static final DeferredItem<ArmorItem> RUBY_LEGGINGS = ITEMS.register("ruby_leggings", () -> new ArmorItem(
            ModArmorMaterials.RUBY, ArmorItem.Type.LEGGINGS, new Item.Properties().durability(ArmorItem.Type.LEGGINGS.getDurability(35))));
    public static final DeferredItem<ArmorItem> RUBY_BOOTS = ITEMS.register("ruby_boots", () -> new ArmorItem(
            ModArmorMaterials.RUBY, ArmorItem.Type.BOOTS, new Item.Properties().durability(ArmorItem.Type.BOOTS.getDurability(35))));

    public static final DeferredItem<DragonArmorItem> DRAGON_ARMOR = ITEMS.register("dragon_armor",
            () -> new DragonArmorItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)));

    public static final DeferredItem<BlockItem> RUBY_BLOCK = block("ruby_block", ModBlocks.RUBY_BLOCK);
    public static final DeferredItem<BlockItem> RUBY_ORE = block("ruby_ore", ModBlocks.RUBY_ORE);
    public static final DeferredItem<BlockItem> RUBY_LAMP = block("ruby_lamp", ModBlocks.RUBY_LAMP);
    public static final DeferredItem<BlockItem> RUBY_BRICKS = block("ruby_bricks", ModBlocks.RUBY_BRICKS);

    /** Huevos de generación (uno por cada humano y cada dragón). */
    public static final List<DeferredItem<DeferredSpawnEggItem>> SPAWN_EGGS = new ArrayList<>();

    static {
        for (HumanoidType type : HumanoidType.values()) {
            SPAWN_EGGS.add(ITEMS.register(type.id + "_spawn_egg", () -> new DeferredSpawnEggItem(
                    ModEntities.HUMANOIDS.get(type), type.eggBackground, type.eggSpots, new Item.Properties())));
        }
        for (DragonType type : DragonType.values()) {
            SPAWN_EGGS.add(ITEMS.register(type.id + "_spawn_egg", () -> new DeferredSpawnEggItem(
                    ModEntities.DRAGONS.get(type), type.eggBackground, type.eggSpots, new Item.Properties())));
        }
    }

    private static DeferredItem<BlockItem> block(String name, DeferredBlock<Block> block) {
        return ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
    }

    private ModItems() {
    }
}
