package com.civilizacionnether.client;

import com.civilizacionnether.entity.NetherHumanoidEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.GeoRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;
import software.bernie.geckolib.renderer.layer.BlockAndItemGeoLayer;

/**
 * El modelo mide 2 bloques; se escala x1,2 para quedar a la altura del Wither Skeleton (2,4 bloques).
 * Ojos y gemas brillan en la oscuridad (texturas _glowmask).
 */
public class HumanoidRenderer extends GeoEntityRenderer<NetherHumanoidEntity> {
    public HumanoidRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel());
        withScale(1.2f);
        this.shadowRadius = 0.5f;
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
        addRenderLayer(new HeldItemLayer(this));
    }

    private static class HeldItemLayer extends BlockAndItemGeoLayer<NetherHumanoidEntity> {
        HeldItemLayer(GeoRenderer<NetherHumanoidEntity> renderer) {
            super(renderer);
        }

        @Nullable
        @Override
        protected ItemStack getStackForBone(GeoBone bone, NetherHumanoidEntity animatable) {
            return switch (bone.getName()) {
                case "right_hand_item" -> animatable.getMainHandItem();
                case "left_hand_item" -> animatable.getOffhandItem();
                default -> null;
            };
        }

        @Override
        protected ItemDisplayContext getTransformTypeForStack(GeoBone bone, ItemStack stack, NetherHumanoidEntity animatable) {
            return bone.getName().equals("left_hand_item")
                    ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND;
        }

        @Override
        protected void renderStackForBone(PoseStack poseStack, GeoBone bone, ItemStack stack, NetherHumanoidEntity animatable,
                                          MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay) {
            poseStack.mulPose(Axis.XP.rotationDegrees(-90f));
            if (stack.getItem() instanceof ShieldItem) {
                poseStack.translate(0, 0.125, -0.25);
            }
            super.renderStackForBone(poseStack, bone, stack, animatable, bufferSource, partialTick, packedLight, packedOverlay);
        }
    }
}
