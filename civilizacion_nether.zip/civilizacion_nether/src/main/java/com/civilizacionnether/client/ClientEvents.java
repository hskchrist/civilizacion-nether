package com.civilizacionnether.client;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.DragonType;
import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherDragonEntity;
import com.civilizacionnether.network.DragonBreathPayload;
import com.civilizacionnether.registry.ModEntities;
import com.civilizacionnether.registry.ModItems;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.item.ItemProperties;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

public final class ClientEvents {
    public static final KeyMapping BREATH_KEY = new KeyMapping("key.civilizacion_nether.breath",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_R, "key.categories.civilizacion_nether");

    @EventBusSubscriber(modid = CivilizacionNether.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ModBus {
        @SubscribeEvent
        public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
            for (HumanoidType type : HumanoidType.values()) {
                event.registerEntityRenderer(ModEntities.HUMANOIDS.get(type).get(), HumanoidRenderer::new);
            }
            for (DragonType type : DragonType.values()) {
                event.registerEntityRenderer(ModEntities.DRAGONS.get(type).get(), DragonRenderer::new);
            }
        }

        @SubscribeEvent
        public static void keys(RegisterKeyMappingsEvent event) {
            event.register(BREATH_KEY);
        }

        @SubscribeEvent
        public static void setup(FMLClientSetupEvent event) {
            event.enqueueWork(() -> {
                // Animación de tensado del arco de rubí
                ItemProperties.register(ModItems.RUBY_BOW.get(), ResourceLocation.withDefaultNamespace("pull"),
                        (stack, level, entity, seed) -> {
                            if (entity == null || entity.getUseItem() != stack) {
                                return 0.0f;
                            }
                            return (stack.getUseDuration(entity) - entity.getUseItemRemainingTicks()) / 20.0f;
                        });
                ItemProperties.register(ModItems.RUBY_BOW.get(), ResourceLocation.withDefaultNamespace("pulling"),
                        (stack, level, entity, seed) -> entity != null && entity.isUsingItem() && entity.getUseItem() == stack ? 1.0f : 0.0f);
            });
        }

        private ModBus() {
        }
    }

    @EventBusSubscriber(modid = CivilizacionNether.MODID, value = Dist.CLIENT)
    public static final class GameBus {
        @SubscribeEvent
        public static void clientTick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            while (BREATH_KEY.consumeClick()) {
                if (mc.player != null && mc.player.getVehicle() instanceof NetherDragonEntity) {
                    PacketDistributor.sendToServer(new DragonBreathPayload());
                }
            }
        }

        private GameBus() {
        }
    }

    private ClientEvents() {
    }
}
