package com.civilizacionnether.client;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.DragonType;
import com.civilizacionnether.entity.NetherDragonEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.model.GeoModel;

import java.util.EnumMap;
import java.util.Map;

/** Modelo de dragón (12-18 bloques de largo, 20-28 de envergadura); silla y armadura se muestran si las tiene. */
public class DragonModel extends GeoModel<NetherDragonEntity> {
    private static final ResourceLocation MODEL = CivilizacionNether.id("geo/entity/dragon.geo.json");
    private static final ResourceLocation ANIMATIONS = CivilizacionNether.id("animations/entity/dragon.animation.json");
    private static final Map<DragonType, ResourceLocation> TEXTURES = new EnumMap<>(DragonType.class);

    static {
        for (DragonType type : DragonType.values()) {
            TEXTURES.put(type, CivilizacionNether.id("textures/entity/" + type.id + ".png"));
        }
    }

    @Override
    public ResourceLocation getModelResource(NetherDragonEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(NetherDragonEntity animatable) {
        return TEXTURES.get(animatable.getDragonType());
    }

    @Override
    public ResourceLocation getAnimationResource(NetherDragonEntity animatable) {
        return ANIMATIONS;
    }

    @Override
    public void setCustomAnimations(NetherDragonEntity animatable, long instanceId, AnimationState<NetherDragonEntity> animationState) {
        super.setCustomAnimations(animatable, instanceId, animationState);
        GeoBone saddle = getAnimationProcessor().getBone("saddle");
        if (saddle != null) {
            saddle.setHidden(!animatable.isSaddled());
        }
        GeoBone armor = getAnimationProcessor().getBone("armor");
        if (armor != null) {
            armor.setHidden(!animatable.isArmored());
        }
    }
}
