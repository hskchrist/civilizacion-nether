package com.civilizacionnether.client;

import com.civilizacionnether.entity.NetherDragonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

public class DragonRenderer extends GeoEntityRenderer<NetherDragonEntity> {
    public DragonRenderer(EntityRendererProvider.Context context) {
        super(context, new DragonModel());
        this.shadowRadius = 2.2f;
        addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }
}
