package com.civilizacionnether.client;

import com.civilizacionnether.CivilizacionNether;
import com.civilizacionnether.entity.HumanoidType;
import com.civilizacionnether.entity.NetherHumanoidEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.constant.DataTickets;
import software.bernie.geckolib.model.GeoModel;
import software.bernie.geckolib.model.data.EntityModelData;

import java.util.EnumMap;
import java.util.Map;

/** Modelo biped compartido por los 15 tipos; cada tipo muestra sus propias piezas (corona, sombrero, capa…). */
public class HumanoidModel extends GeoModel<NetherHumanoidEntity> {
    private static final ResourceLocation MODEL = CivilizacionNether.id("geo/entity/humanoid.geo.json");
    private static final ResourceLocation ANIMATIONS = CivilizacionNether.id("animations/entity/humanoid.animation.json");
    private static final Map<HumanoidType, ResourceLocation> TEXTURES = new EnumMap<>(HumanoidType.class);

    static {
        for (HumanoidType type : HumanoidType.values()) {
            TEXTURES.put(type, CivilizacionNether.id("textures/entity/" + type.id + ".png"));
        }
    }

    @Override
    public ResourceLocation getModelResource(NetherHumanoidEntity animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(NetherHumanoidEntity animatable) {
        return TEXTURES.get(animatable.getHumanoidType());
    }

    @Override
    public ResourceLocation getAnimationResource(NetherHumanoidEntity animatable) {
        return ANIMATIONS;
    }

    @Override
    public void setCustomAnimations(NetherHumanoidEntity animatable, long instanceId, AnimationState<NetherHumanoidEntity> animationState) {
        super.setCustomAnimations(animatable, instanceId, animationState);
        HumanoidType type = animatable.getHumanoidType();
        for (String name : HumanoidType.OPTIONAL_BONES) {
            GeoBone bone = getAnimationProcessor().getBone(name);
            if (bone != null) {
                bone.setHidden(!type.visibleBones.contains(name));
            }
        }
        GeoBone head = getAnimationProcessor().getBone("head");
        EntityModelData data = animationState.getData(DataTickets.ENTITY_MODEL_DATA);
        if (head != null && data != null) {
            head.setRotX(data.headPitch() * Mth.DEG_TO_RAD);
            head.setRotY(data.netHeadYaw() * Mth.DEG_TO_RAD);
        }
    }
}
