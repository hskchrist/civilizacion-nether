package com.civilizacionnether.item;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;

/** Báculo de rubí: lanza un rayo de rubí que daña y quema al primer objetivo en la mira. */
public class RubyStaffItem extends Item {
    public static final double RANGE = 24.0;

    public RubyStaffItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel server) {
            Vec3 start = player.getEyePosition();
            Vec3 end = start.add(player.getLookAngle().scale(RANGE));
            HitResult blockHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (blockHit.getType() != HitResult.Type.MISS) {
                end = blockHit.getLocation();
            }
            LivingEntity best = null;
            double bestDist = Double.MAX_VALUE;
            AABB area = new AABB(start, end).inflate(1.5);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, area, e -> e != player && e.isAlive() && !e.isAlliedTo(player))) {
                Optional<Vec3> hit = e.getBoundingBox().inflate(0.3).clip(start, end);
                if (hit.isPresent()) {
                    double d = start.distanceToSqr(hit.get());
                    if (d < bestDist) {
                        bestDist = d;
                        best = e;
                    }
                }
            }
            if (best != null) {
                end = best.getBoundingBox().getCenter();
                best.hurt(level.damageSources().indirectMagic(player, player), 8.0f);
                best.setRemainingFireTicks(60);
            }
            Vec3 dir = end.subtract(start);
            int steps = (int) Math.max(4, dir.length() * 2);
            for (int i = 1; i <= steps; i++) {
                Vec3 p = start.add(dir.scale(i / (double) steps));
                server.sendParticles(ParticleTypes.FLAME, p.x, p.y - 0.2, p.z, 1, 0.02, 0.02, 0.02, 0.0);
                if (i % 3 == 0) {
                    server.sendParticles(ParticleTypes.CRIMSON_SPORE, p.x, p.y - 0.2, p.z, 2, 0.05, 0.05, 0.05, 0.0);
                }
            }
            level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.8f, 1.3f);
            stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        }
        player.getCooldowns().addCooldown(this, 20);
        player.swing(hand);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.civilizacion_nether.ruby_staff").withStyle(ChatFormatting.RED));
    }
}
