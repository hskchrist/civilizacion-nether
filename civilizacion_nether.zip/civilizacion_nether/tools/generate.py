"""Regenera TODOS los recursos del mod (modelos, animaciones, texturas, datos y la capital).

Uso:  python tools/generate.py      (requiere Python 3 y Pillow:  pip install pillow)

Si editas un modelo o una textura a mano en Blockbench, NO vuelvas a ejecutar este script
o se sobrescribirán tus cambios.
"""
import models
import textures
import datagen
import structure

if __name__ == "__main__":
    h, d = models.write_all()
    textures.write_all(h, d)
    textures.glowmasks()
    datagen.write_all()
    _, info = structure.write_all()
    print("Recursos generados. Capital: %d bloques, %d tipos de bloque, %d habitantes." % info)
