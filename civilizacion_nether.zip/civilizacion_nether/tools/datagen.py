"""Genera los JSON de datos y recursos: idiomas, modelos de ítem, estados de bloque, recetas, botín, spawns y mena."""
import os
from common import *

ITEMS_ES = {
    "ruby": ("Rubí", "Ruby"),
    "ruby_sword": ("Espada de rubí", "Ruby Sword"),
    "ruby_staff": ("Báculo de rubí", "Ruby Staff"),
    "ruby_bow": ("Arco de rubí", "Ruby Bow"),
    "ruby_helmet": ("Casco de rubí", "Ruby Helmet"),
    "ruby_chestplate": ("Peto de rubí", "Ruby Chestplate"),
    "ruby_leggings": ("Grebas de rubí", "Ruby Leggings"),
    "ruby_boots": ("Botas de rubí", "Ruby Boots"),
    "dragon_armor": ("Armadura de dragón", "Dragon Armor"),
}
BLOCKS_ES = {
    "ruby_block": ("Bloque de rubí", "Block of Ruby"),
    "ruby_ore": ("Mena de rubí del Nether", "Nether Ruby Ore"),
    "ruby_lamp": ("Lámpara de rubí", "Ruby Lamp"),
    "ruby_bricks": ("Ladrillos de rubí", "Ruby Bricks"),
}
EGG_COLORS = {  # fondo, manchas (deben coincidir con ModItems.java solo como referencia visual)
}


def lang():
    es, en = {}, {}
    for tid, nes, nen in HUMANOIDS + DRAGONS:
        es["entity.%s.%s" % (MODID, tid)] = nes
        en["entity.%s.%s" % (MODID, tid)] = nen
        es["item.%s.%s_spawn_egg" % (MODID, tid)] = "Huevo de generación de %s" % nes
        en["item.%s.%s_spawn_egg" % (MODID, tid)] = "%s Spawn Egg" % nen
    for k, (a, b) in ITEMS_ES.items():
        es["item.%s.%s" % (MODID, k)] = a
        en["item.%s.%s" % (MODID, k)] = b
    for k, (a, b) in BLOCKS_ES.items():
        es["block.%s.%s" % (MODID, k)] = a
        en["block.%s.%s" % (MODID, k)] = b
    extra = {
        "itemGroup.civilizacion_nether": ("Civilización del Nether", "Nether Civilization"),
        "key.categories.civilizacion_nether": ("Civilización del Nether", "Nether Civilization"),
        "key.civilizacion_nether.breath": ("Aliento del dragón", "Dragon breath"),
        "msg.civilizacion_nether.tamed": ("¡%s ahora te sigue!", "%s now follows you!"),
        "msg.civilizacion_nether.tame_fail": ("%s no está convencido todavía…", "%s is not convinced yet…"),
        "msg.civilizacion_nether.sit": ("%s se queda aquí.", "%s will stay here."),
        "msg.civilizacion_nether.follow": ("%s te sigue.", "%s follows you."),
        "msg.civilizacion_nether.need_saddle": ("Coloca una silla al dragón para montarlo.", "Put a saddle on the dragon to ride it."),
        "msg.civilizacion_nether.not_owner": ("Este dragón no es tuyo.", "This dragon is not yours."),
        "msg.civilizacion_nether.bond": ("Vínculo con %s: %s/100", "Bond with %s: %s/100"),
        "msg.civilizacion_nether.ride_hint": ("Mira hacia arriba y avanza para despegar. Tecla R: aliento.",
                                             "Look up and move forward to take off. Key R: breath."),
        "tooltip.civilizacion_nether.ruby_staff": ("Clic derecho: lanza un rayo de rubí", "Right click: casts a ruby bolt"),
        "tooltip.civilizacion_nether.dragon_armor": ("Úsala sobre un dragón domesticado", "Use it on a tamed dragon"),
    }
    for k, (a, b) in extra.items():
        es[k] = a
        en[k] = b
    save_json(os.path.join(ASSETS, "lang", "es_es.json"), es)
    for code in ("es_cl", "es_mx", "es_ar", "es_es"):
        save_json(os.path.join(ASSETS, "lang", code + ".json"), es)
    save_json(os.path.join(ASSETS, "lang", "en_us.json"), en)


def models():
    im = os.path.join(ASSETS, "models", "item")
    for k in ["ruby", "ruby_helmet", "ruby_chestplate", "ruby_leggings", "ruby_boots", "dragon_armor"]:
        save_json(os.path.join(im, k + ".json"), {"parent": "minecraft:item/generated",
                                                  "textures": {"layer0": "%s:item/%s" % (MODID, k)}})
    for k in ["ruby_sword", "ruby_staff"]:
        save_json(os.path.join(im, k + ".json"), {"parent": "minecraft:item/handheld",
                                                  "textures": {"layer0": "%s:item/%s" % (MODID, k)}})
    bow = {"parent": "minecraft:item/bow", "textures": {"layer0": "%s:item/ruby_bow" % MODID}, "overrides": [
        {"predicate": {"pulling": 1}, "model": "%s:item/ruby_bow_pulling_0" % MODID},
        {"predicate": {"pulling": 1, "pull": 0.65}, "model": "%s:item/ruby_bow_pulling_1" % MODID},
        {"predicate": {"pulling": 1, "pull": 0.9}, "model": "%s:item/ruby_bow_pulling_2" % MODID}]}
    save_json(os.path.join(im, "ruby_bow.json"), bow)
    for i in range(3):
        save_json(os.path.join(im, "ruby_bow_pulling_%d.json" % i),
                  {"parent": "%s:item/ruby_bow" % MODID, "textures": {"layer0": "%s:item/ruby_bow_pulling_%d" % (MODID, i)}})
    for tid, _, _ in HUMANOIDS + DRAGONS:
        save_json(os.path.join(im, tid + "_spawn_egg.json"), {"parent": "minecraft:item/template_spawn_egg"})
    for b in BLOCKS_ES:
        save_json(os.path.join(ASSETS, "blockstates", b + ".json"), {"variants": {"": {"model": "%s:block/%s" % (MODID, b)}}})
        save_json(os.path.join(ASSETS, "models", "block", b + ".json"),
                  {"parent": "minecraft:block/cube_all", "textures": {"all": "%s:block/%s" % (MODID, b)}})
        save_json(os.path.join(im, b + ".json"), {"parent": "%s:block/%s" % (MODID, b)})


def item(i, n=1):
    return {"id": i, "count": n}


def shaped(name, pattern, key, result, count=1, cat="misc"):
    save_json(os.path.join(DATA, "recipe", name + ".json"), {
        "type": "minecraft:crafting_shaped", "category": cat, "pattern": pattern,
        "key": {k: {"item": v} for k, v in key.items()}, "result": item(result, count)})


def recipes():
    R = MODID + ":ruby"
    shaped("ruby_block", ["RRR", "RRR", "RRR"], {"R": R}, MODID + ":ruby_block", cat="building")
    save_json(os.path.join(DATA, "recipe", "ruby_from_block.json"), {
        "type": "minecraft:crafting_shapeless", "category": "misc",
        "ingredients": [{"item": MODID + ":ruby_block"}], "result": item(R, 9)})
    shaped("ruby_bricks", ["RN", "NR"], {"R": R, "N": "minecraft:nether_bricks"}, MODID + ":ruby_bricks", 4, "building")
    shaped("ruby_lamp", [" G ", "RSR", " G "], {"R": R, "G": "minecraft:gold_ingot", "S": "minecraft:shroomlight"},
           MODID + ":ruby_lamp", 2, "building")
    shaped("ruby_sword", ["R", "R", "B"], {"R": R, "B": "minecraft:blaze_rod"}, MODID + ":ruby_sword", cat="equipment")
    shaped("ruby_staff", [" RG", " BR", "B  "], {"R": R, "G": "minecraft:gold_ingot", "B": "minecraft:blaze_rod"},
           MODID + ":ruby_staff", cat="equipment")
    shaped("ruby_bow", [" RS", "B S", " RS"], {"R": R, "B": "minecraft:blaze_rod", "S": "minecraft:string"},
           MODID + ":ruby_bow", cat="equipment")
    shaped("ruby_helmet", ["RRR", "R R"], {"R": R}, MODID + ":ruby_helmet", cat="equipment")
    shaped("ruby_chestplate", ["R R", "RRR", "RRR"], {"R": R}, MODID + ":ruby_chestplate", cat="equipment")
    shaped("ruby_leggings", ["RRR", "R R", "R R"], {"R": R}, MODID + ":ruby_leggings", cat="equipment")
    shaped("ruby_boots", ["R R", "R R"], {"R": R}, MODID + ":ruby_boots", cat="equipment")
    shaped("dragon_armor", ["  R", "RBR", "RRR"], {"R": R, "B": MODID + ":ruby_block"}, MODID + ":dragon_armor", cat="equipment")
    for name, src in [("ruby_from_smelting", "minecraft:smelting"), ("ruby_from_blasting", "minecraft:blasting")]:
        save_json(os.path.join(DATA, "recipe", name + ".json"), {
            "type": src, "category": "misc", "ingredient": {"item": MODID + ":ruby_ore"},
            "result": {"id": R}, "experience": 1.0, "cookingtime": 200 if "smelt" in name else 100})


def loot():
    lt = os.path.join(DATA, "loot_table")
    for b in ["ruby_block", "ruby_lamp", "ruby_bricks"]:
        save_json(os.path.join(lt, "blocks", b + ".json"), {
            "type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:item", "name": "%s:%s" % (MODID, b)}],
                                                   "conditions": [{"condition": "minecraft:survives_explosion"}]}]})
    save_json(os.path.join(lt, "blocks", "ruby_ore.json"), {
        "type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{"type": "minecraft:alternatives", "children": [
            {"type": "minecraft:item", "name": MODID + ":ruby_ore", "conditions": [{"condition": "minecraft:match_tool", "predicate": {
                "predicates": {"minecraft:enchantments": [{"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}]},
            {"type": "minecraft:item", "name": MODID + ":ruby", "functions": [
                {"function": "minecraft:apply_bonus", "enchantment": "minecraft:fortune", "formula": "minecraft:ore_drops"},
                {"function": "minecraft:explosion_decay"}]}]}]}]})

    def entity(name, entries):
        save_json(os.path.join(lt, "entities", name + ".json"), {"type": "minecraft:entity", "pools": entries})

    def pool(itm, lo, hi, chance=None):
        p = {"rolls": 1, "entries": [{"type": "minecraft:item", "name": itm, "functions": [
            {"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]}]}
        if chance:
            p["conditions"] = [{"condition": "minecraft:random_chance", "chance": chance}]
        return p
    R = MODID + ":ruby"
    for tid, _, _ in HUMANOIDS:
        if tid == "alma_nether":
            entity(tid, [])
            continue
        rich = tid in ("noble", "sacerdote_supremo", "guardia_real", "caballero_rubi")
        entity(tid, [pool(R, 1 if rich else 0, 3 if rich else 1), pool("minecraft:gold_nugget", 1, 4, 0.5)])
    extra = {"dragon_rubi": "minecraft:redstone", "dragon_obsidiana": "minecraft:obsidian",
             "dragon_fuego": "minecraft:magma_cream", "dragon_hueso": "minecraft:bone"}
    for did, _, _ in DRAGONS:
        entity(did, [pool(R, 3, 7), pool(extra[did], 2, 6), pool("minecraft:leather", 2, 5)])


def tags():
    blocks = [MODID + ":" + b for b in BLOCKS_ES]
    save_json(os.path.join(MCDATA, "tags", "block", "mineable", "pickaxe.json"), {"replace": False, "values": blocks})
    save_json(os.path.join(MCDATA, "tags", "block", "needs_iron_tool.json"),
              {"replace": False, "values": [MODID + ":ruby_ore", MODID + ":ruby_block"]})
    save_json(os.path.join(MCDATA, "tags", "item", "beacon_payment_items.json"), {"replace": False, "values": [MODID + ":ruby"]})
    save_json(os.path.join(MCDATA, "tags", "block", "beacon_base_blocks.json"), {"replace": False, "values": [MODID + ":ruby_block"]})


SPAWNS = [  # (id, peso, min, max)
    ("civil_comun", 14, 2, 4), ("aldeano_nether", 8, 1, 2), ("guerrero", 10, 2, 3), ("arquero", 8, 1, 3),
    ("mago", 4, 1, 1), ("summoner", 3, 1, 1), ("sacerdote", 3, 1, 1), ("noble", 2, 1, 1),
    ("guardia_real", 3, 1, 2), ("caballero_rubi", 2, 1, 1), ("arquero_elite", 2, 1, 2), ("mago_batalla", 2, 1, 1),
    ("berserker", 3, 1, 2), ("sacerdote_supremo", 1, 1, 1),
    ("dragon_obsidiana", 2, 1, 1), ("dragon_fuego", 1, 1, 1), ("dragon_rubi", 1, 1, 1), ("dragon_hueso", 1, 1, 1),
]


def worldgen():
    bm = os.path.join(DATA, "neoforge", "biome_modifier")
    save_json(os.path.join(bm, "spawns.json"), {
        "type": "neoforge:add_spawns", "biomes": "#minecraft:is_nether",
        "spawners": [{"type": "%s:%s" % (MODID, t), "weight": w, "minCount": a, "maxCount": b} for t, w, a, b in SPAWNS]})
    save_json(os.path.join(bm, "ruby_ore.json"), {
        "type": "neoforge:add_features", "biomes": "#minecraft:is_nether",
        "features": MODID + ":ruby_ore", "step": "underground_decoration"})
    save_json(os.path.join(DATA, "worldgen", "configured_feature", "ruby_ore.json"), {
        "type": "minecraft:ore", "config": {"size": 5, "discard_chance_on_air_exposure": 0.0, "targets": [
            {"target": {"predicate_type": "minecraft:block_match", "block": "minecraft:netherrack"},
             "state": {"Name": MODID + ":ruby_ore"}}]}})
    save_json(os.path.join(DATA, "worldgen", "placed_feature", "ruby_ore.json"), {
        "feature": MODID + ":ruby_ore", "placement": [
            {"type": "minecraft:count", "count": 12}, {"type": "minecraft:in_square"},
            {"type": "minecraft:height_range", "height": {"type": "minecraft:uniform",
                                                           "min_inclusive": {"above_bottom": 10}, "max_inclusive": {"below_top": 10}}},
            {"type": "minecraft:biome"}]})
    # capital del reino (estructura jigsaw de una pieza)
    save_json(os.path.join(DATA, "worldgen", "structure", "capital.json"), {
        "type": "minecraft:jigsaw", "biomes": "#minecraft:is_nether", "step": "surface_structures",
        "spawn_overrides": {}, "terrain_adaptation": "none",
        "start_pool": MODID + ":capital/start", "size": 1, "start_height": {"absolute": 30},
        "max_distance_from_center": 80, "use_expansion_hack": False})
    save_json(os.path.join(DATA, "worldgen", "template_pool", "capital", "start.json"), {
        "fallback": "minecraft:empty", "elements": [{"weight": 1, "element": {
            "element_type": "minecraft:single_pool_element", "location": MODID + ":capital",
            "projection": "rigid", "processors": "minecraft:empty"}}]})
    save_json(os.path.join(DATA, "worldgen", "structure_set", "capital.json"), {
        "structures": [{"structure": MODID + ":capital", "weight": 1}],
        "placement": {"type": "minecraft:random_spread", "spacing": 36, "separation": 16, "salt": 74839201}})
    save_json(os.path.join(DATA, "tags", "worldgen", "structure", "capitales.json"), {"values": [MODID + ":capital"]})


def write_all():
    lang()
    models()
    recipes()
    loot()
    tags()
    worldgen()
