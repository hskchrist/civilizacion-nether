# Civilización del Nether

Mod para **Minecraft Java 1.21.1** con **NeoForge** (requiere **GeckoLib 4.7+**).

- 15 humanos del Nether (modelo biped de 2,4 bloques, igual que el Wither Skeleton) con funciones y animaciones propias.
- Aliados del jugador, aldeanos, golems y todos sus aliados; atacan a los mobs hostiles.
- Se domestican con **varas de blaze** y se reproducen con **chuleta de cerdo asada**.
- 4 dragones domesticables y montables (rubí, obsidiana, fuego, hueso): vuelo, aliento, silla, armadura y vínculo.
- La capital del Reino del Nether se genera en el Nether.
- Rubí, mena, bloques, espada, arco, báculo y armadura de rubí.

El manual completo está en `Manual_Civilizacion_del_Nether.docx`.

## Obtener el .jar

**Opción fácil (sin instalar nada):** sube esta carpeta a un repositorio de GitHub. La pestaña **Actions**
compila el mod sola; descarga el artefacto `civilizacion_nether-jar`.

**En tu PC:** instala Java 21 y Gradle 8.14, abre una terminal en esta carpeta y ejecuta `gradle build`.
El mod queda en `build/libs/civilizacion_nether-1.0.0.jar`.

## Regenerar recursos

`python tools/generate.py` (requiere Pillow). Sobrescribe modelos y texturas.
